#include "debug.h"
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include "ch32v00x_flash.h"
#include <string.h>

#define FLASH_DATA_ADDR    0x08003000

int contador;

uint8_t buffer[]={ 0x0a, 0x01, 0x17, 0xd0, 0x04, 0x00, 0x07, 0x8a, 0x1f, 0x10, 0xff, 0xcf, 0x3f, 0x97, 0x85, 0x07, 
0x0f, 0x3f, 0x05, 0x07, 0xb9, 0x1f, 0x27, 0x8f, 0x82, 0x80, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 
0x00, 0x00, 0x00, 0x01, 0x00, 0x33, 0x45, 0x22, 0x36, 0x1e, 0x17, 0x1a, 0x1c, 0x0b, 0x23, 0x5d, 
0x30, 0x37, 0x00, 0x00, 0x44, 0x41, 0x0a, 0x86, 0x0a, 0x01, 0x17, 0xd0, 0x04, 0x00, 0x07, 0x8a, 
0x1f, 0x10, 0xff, 0xcf, 0x3f, 0x97, 0x85, 0x07, 0x0f, 0x3f, 0x05, 0x07, 0xb9, 0x1f, 0x27, 0x8f, 
0x82, 0x80, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x33, 0x45, 0x22, 
0x36, 0x1e, 0x17, 0x1a, 0x1c, 0x0b, 0x23, 0x5d, 0x30, 0x37, 0x00, 0x00, 0x44, 0x41, 0x0a, 0x86, 
0x0a, 0x01, 0x0c, 0xed, 0x04, 0x00, 0x18, 0xd4, 0x1f, 0x10, 0xff, 0xcf, 0x3f, 0x97, 0x85, 0x07, 
0x0f, 0x3f, 0x05, 0x07, 0xb9, 0x1e, 0x27, 0x8b, 0x82, 0x80, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 
0x00, 0x00, 0x00, 0x01, 0x00, 0x21, 0x44, 0x22, 0x3f, 0x1e, 0x17, 0x1a, 0x1c, 0x0b, 0x14, 0x5d, 
0x30, 0x37, 0x00, 0x00, 0x44, 0x41, 0x0a, 0xd5, 0x0a, 0x01, 0x0c, 0xed, 0x04, 0x00, 0x18, 0xd4,
0x1f, 0x10, 0xff, 0xcf, 0x3f, 0x97, 0x85, 0x07, 0x0f, 0x3f, 0x05, 0x07, 0xb9, 0x1e, 0x27, 0x8b, 
0x82, 0x80, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x21, 0x44, 0x22,
0x3f, 0x1e, 0x17, 0x1a, 0x1c, 0x0b, 0x14, 0x5d, 0x30, 0x37, 0x00, 0x00, 0x44, 0x41, 0x0a, 0xd5, 
0x0a, 0x01, 0x17, 0xd0, 0x04, 0x00, 0x07, 0x8a, 0x1f, 0x10, 0xff, 0xcf, 0x3f, 0x97, 0x85, 0x07, 
0x0f, 0x3f, 0x05, 0x07, 0xb9, 0x1f, 0x27, 0x8f, 0x82, 0x80, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 
0x00, 0x00, 0x00, 0x01, 0x00, 0x33, 0x38, 0x22, 0x36, 0x1e, 0x17, 0x1a, 0x1c, 0x0b, 0x23, 0x5d, 
0x30, 0x37, 0x00, 0x00, 0x44, 0x41, 0x0a, 0x79, 0x0a, 0x01, 0x17, 0xd0, 0x04, 0x00, 0x07, 0x8a, 
0x1f, 0x10, 0xff, 0xcf, 0x3f, 0x97, 0x85, 0x07, 0x0f, 0x3f, 0x05, 0x07, 0xb9, 0x1f, 0x27, 0x8f, 
0x82, 0x80, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x33, 0x38, 0x22,
0x36, 0x1e, 0x17, 0x1a, 0x1c, 0x0b, 0x23, 0x5d, 0x30, 0x37, 0x00, 0x00, 0x44, 0x41, 0x0a, 0x79, 
0x0a, 0x01, 0x0c, 0xed, 0x04, 0x00, 0x18, 0xd4, 0x1f, 0x10, 0xff, 0xcf, 0x3f, 0x97, 0x85, 0x07, 
0x0f, 0x3f, 0x05, 0x07, 0xb9, 0x1e, 0x27, 0x8b, 0x82, 0x80, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01,
0x00, 0x00, 0x00, 0x01, 0x00, 0x36, 0x4f, 0x22, 0x36, 0x1e, 0x17, 0x1a, 0x1c, 0x0b, 0x14, 0x5d, 
0x30, 0x37, 0x00, 0x00, 0x44, 0x41, 0x0a, 0xec, 0x0a, 0x01, 0x0c, 0xed, 0x04, 0x00, 0x18, 0xd4, 
0x1f, 0x10, 0xff, 0xcf, 0x3f, 0x97, 0x85, 0x07, 0x0f, 0x3f, 0x05, 0x07, 0xb9, 0x1e, 0x27, 0x8b, 
0x82, 0x80, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x36, 0x4f, 0x22, 
0x36, 0x1e, 0x17, 0x1a, 0x1c, 0x0b, 0x14, 0x5d, 0x30, 0x37, 0x00, 0x00, 0x44, 0x41, 0x0a, 0xec, 
0x3f, 0xf7, 0xff, 0xb1, 0x15, 0x59, 0x55, 0xd7, 0x00, 0x00, 0x00, 0x08, 0x2a, 0xae, 0xaa, 0x6e,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x48, 0x49, 0x07, 0x09, 
0x3f, 0xf7, 0xff, 0xb1, 0x15, 0x59, 0x55, 0xd7, 0x00, 0x00, 0x00, 0x08, 0x2a, 0xae, 0xaa, 0x6e, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x48, 0x49, 0x07, 0x09 };





/* Global define */
#define HIGH   1
#define LOW    0

#define INPUT  0
#define OUTPUT 1

#define PC0    0
#define PC1    1
#define PC2    2
#define PC3    3
#define PC4    4
#define PC5    5
#define PC6    6
#define PC7    7
#define PD0    8
#define PD1    9
#define PD2   10
#define PD3   11
#define PD4   12
#define PD5   13
#define PD6   14
#define PD7   15  // RST
#define PA1   16  // X1
#define PA2   17  // X0



///DigitalRead

#define digitalReadPA1 (GPIOA->INDR>>1)&1
#define digitalReadPA2 (GPIOA->INDR>>2)&1

#define digitalReadPC0 (GPIOC->INDR>>0)&1
#define digitalReadPC1 (GPIOC->INDR>>1)&1
#define digitalReadPC2 (GPIOC->INDR>>2)&1
#define digitalReadPC3 (GPIOC->INDR>>3)&1
#define digitalReadPC4 (GPIOC->INDR>>4)&1
#define digitalReadPC5 (GPIOC->INDR>>5)&1
#define digitalReadPC6 (GPIOC->INDR>>6)&1
#define digitalReadPC7 (GPIOC->INDR>>7)&1

#define digitalReadPD0 (GPIOD->INDR>>0)&1
#define digitalReadPD1 (GPIOD->INDR>>1)&1
#define digitalReadPD2 (GPIOD->INDR>>2)&1
#define digitalReadPD3 (GPIOD->INDR>>3)&1
#define digitalReadPD4 (GPIOD->INDR>>4)&1
#define digitalReadPD5 (GPIOD->INDR>>5)&1
#define digitalReadPD6 (GPIOD->INDR>>6)&1
#define digitalReadPD7 (GPIOD->INDR>>7)&1

//DigitaWrite

#define enciendePD2 GPIOD->BSHR=(1<<2)
#define apagaPD2 GPIOD->BSHR=(1<<(16+2))

#define enciendePD4 GPIOD->BSHR=(1<<4)
#define apagaPD4 GPIOD->BSHR=(1<<(16+4))

#define enciendePC2 GPIOC->BSHR=(1<<2)
#define apagaPC2 GPIOC->BSHR=(1<<(16+2))

void cambiaPC2(){
    int val=(GPIOC->OUTDR>>2)&1;
    if(val==0){ enciendePC2; }
    else{ apagaPC2;}
}

#define enciendePC1 GPIOC->BSHR=(1<<1)
#define apagaPC1 GPIOC->BSHR=(1<<(16 + 1))

void cambiaPC1(){
    int val=(GPIOC->OUTDR>>1)&1;
    if(val==0){ enciendePC1; }
    else{ apagaPC1;}
}

#define enciendePC0 GPIOC->BSHR=(1<<0)
#define apagaPC0 GPIOC->BSHR=(1<<(16 + 0))

void cambiaPC0(){
    int val=(GPIOC->OUTDR>>0)&1;
    if(val==0){ enciendePC0; }
    else{ apagaPC0;}
}



void Delay_750ns(void) {
    __asm volatile (
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
    );
}

void Delay_250ns(void) {
    __asm volatile (
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
        "nop\n" // 1 ciclo
    );
}

long map(long x, long in_min, long in_max, long out_min, long out_max){
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}


/*****************************************************************************************
*/
void pinMode(u8 pin, u8 mode)
{
  GPIO_InitTypeDef GPIO_InitStructure = {0}; // Variable used for the GPIO configuration

  switch (pin)
  {
    case PA1:  // X0
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);  // Enable the clock for Port
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1; // pin
      break;
    case PA2:  // X1
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);  // Enable the clock for Port
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2; // pin
      break;
    case PC0:
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);  // Enable the clock for Port
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0; // pin
      break;
    case PC1:
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);  // Enable the clock for Port
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1; // pin
      break;
    case PC2:
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);  // Enable the clock for Port
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2; // pin
      break;
    case PC3:
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);  // Enable the clock for Port
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3; // pin
      break;
    case PC4:
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);  // Enable the clock for Port
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4; // pin
      break;
    case PC5:
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);  // Enable the clock for Port
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5; // pin
      break;
    case PC6:
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);  // Enable the clock for Port
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6; // pin
      break;
    case PC7:
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);  // Enable the clock for Port
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7; // pin
      break;
    case PD0:
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);  // Enable the clock for Port
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0; // pin
      break;
    case PD1:
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);  // Enable the clock for Port
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1; // pin
      break;
    case PD2:
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);  // Enable the clock for Port
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2; // pin
      break;
    case PD3:
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);  // Enable the clock for Port
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3; // pin
      break;
    case PD4:
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);  // Enable the clock for Port
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4; // pin
      break;
    case PD5:
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);  // Enable the clock for Port
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5; // pin
      break;
    case PD6:
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);  // Enable the clock for Port
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6; // pin
      break;
    case PD7:  // RST
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);  // Enable the clock for Port
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7; // pin
      break;
    default:
      break;
  }

  if (mode == OUTPUT){
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;  // Push-pull output
  }
  else
  {
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;  // Pull-up input
  }

  // Speed
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

  switch (pin)
  {
    case PA1:  // X0
    case PA2:  // X1
      GPIO_Init(GPIOA, &GPIO_InitStructure);
      break;
    case PC0:
    case PC1:
    case PC2:
    case PC3:
    case PC4:
    case PC5:
    case PC6:
    case PC7:
      GPIO_Init(GPIOC, &GPIO_InitStructure);
      break;
    case PD0:
    case PD1:
    case PD2:
    case PD3:
    case PD4:
    case PD5:
    case PD6:
    case PD7:  // RST
      GPIO_Init(GPIOD, &GPIO_InitStructure);
      break;
    default:
      break;
  }
}


void guardar_buffer_en_flash_bloque(uint8_t *buffer,uint8_t bloque) {

    FLASH_Unlock();
    int posbuffer=bloque*64;
    int pos=FLASH_DATA_ADDR+(posbuffer)-512;
    FLASH_ErasePage(pos);
            
    for (int i = 0; i < 64; i ++) {
        uint16_t halfword = buffer[posbuffer] | (buffer[posbuffer + 1] << 8);        
        if (FLASH_ProgramHalfWord(pos, halfword) != FLASH_COMPLETE) {
            //printf("Fallo de escritura\n");
        }else{
            //printf("Se ha escrito bien\n");
        }
        pos+=2;
        posbuffer+=2;
    }
    FLASH_Lock();
}


void guardar_buffer_en_flash(uint8_t *buffer) {
    FLASH_Unlock();
    int pos=0;
    for(int i=0;i<8;i++){
        pos=FLASH_DATA_ADDR-(i*64);
        FLASH_ErasePage(pos);
    }
    
    for (int i = 0; i < 512; i += 2) {
        uint16_t halfword = buffer[i] | (buffer[i + 1] << 8);        
        pos=FLASH_DATA_ADDR+i-512;
        if (FLASH_ProgramHalfWord(pos, halfword) != FLASH_COMPLETE) {
            //printf("Fallo de escritura\n");
        }else{
            //printf("Se ha escrito bien\n");
        }
    }

    FLASH_Lock();
}


void leer_buffer_de_flash(void) {
    memcpy(buffer,(const void *)(FLASH_DATA_ADDR-512),512);
}


void recibebitfinal(){
  //Se recibe el bit final 
    while(!(digitalReadPD2)){}
    
}


void enviabyte(int val){
    pinMode(PD2,OUTPUT); 
    
    for (int j = 7;j>=0;j--) {

            if(((val >> j) & 1)==0){
                
                apagaPD2;Delay_750ns(); Delay_750ns(); Delay_750ns(); 
                /*       
                for (int ii = 0; ii < 6; ii++) {
                    while(digitalReadPD3){ __asm volatile("nop\n"); }
                    while(!(digitalReadPD3)){ __asm volatile("nop\n"); }                      
                }
                */
                enciendePD2;Delay_750ns();  
                /*   
                for (int ii = 0; ii < 2; ii++) {
                    while(digitalReadPD3){__asm volatile("nop\n"); }
                    while(!(digitalReadPD3)){__asm volatile("nop\n"); }         
                }
                */

            }else{

                apagaPD2;Delay_750ns();
                /*        
                for (int ii = 0; ii < 2; ii++) {
                    while(digitalReadPD3){ __asm volatile("nop\n"); }
                    while(!(digitalReadPD3)){ __asm volatile("nop\n"); }                      
                }
                */
                enciendePD2;Delay_750ns(); Delay_750ns(); Delay_750ns();   
                /*  
                for (int ii = 0; ii < 6; ii++) {
                    while(digitalReadPD3){__asm volatile("nop\n"); }
                    while(!(digitalReadPD3)){__asm volatile("nop\n"); }         
                }
                */

            }
    }

    
    pinMode(PD2,INPUT);  
}


void enviadato(int pos){
    pinMode(PD2,OUTPUT); 
    
    for (int i = 0; i < 8; i++) {

        int8_t dato=buffer[pos+i];

        for (int j = 7;j>=0;j--) {

            if(((dato >> j) & 1)==0){
                
                apagaPD2; Delay_750ns(); Delay_750ns(); Delay_750ns();       
               // for (int ii = 0; ii < 6; ii++) {
               //     while(digitalReadPD3){ __asm volatile("nop\n"); }
               //     while(!(digitalReadPD3)){ __asm volatile("nop\n"); }                      
               // }
                enciendePD2; Delay_750ns();    
               // for (int ii = 0; ii < 2; ii++) {
               //     while(digitalReadPD3){__asm volatile("nop\n"); }
               //     while(!(digitalReadPD3)){__asm volatile("nop\n"); }         
               // }

            }else{

                apagaPD2;  Delay_750ns();      
              //  for (int ii = 0; ii < 2; ii++) {
              //      while(digitalReadPD3){ __asm volatile("nop\n"); }
              //      while(!(digitalReadPD3)){ __asm volatile("nop\n"); }                      
              //  }
                enciendePD2; Delay_750ns(); Delay_750ns(); Delay_750ns();    
              //  for (int ii = 0; ii < 6; ii++) {
              //      while(digitalReadPD3){__asm volatile("nop\n"); }
              //      while(!(digitalReadPD3)){__asm volatile("nop\n"); }         
              //  }

            }

        }

    }

    //Bit de final
    apagaPD2;
    Delay_750ns();       
              
    enciendePD2;    
    Delay_750ns();Delay_750ns();Delay_750ns();  

    pinMode(PD2,INPUT);  
}

uint8_t recibedato(){

    int8_t contadorLOW=0;
    uint8_t dato=0;

    while(digitalReadPD2){ /*__asm volatile("nop\n");*/ }

    for(int i=7;i>=0;i--){        
        
        while(!(digitalReadPD2)){ contadorLOW++; }
        while(digitalReadPD2){ contadorLOW--; }
        
        if(contadorLOW<0){ dato |= (1 << i); }
        
        contadorLOW=0;       

    }
    
    return dato;  

}


uint8_t crc8_poly_85(const uint8_t *data, size_t len) {
    
    // Polinomio (0x85) -> x^7 + x^2 + x^0
    // ?Este es el cambio que necesitas!
    const uint8_t poly = 0x85;
    
    // Valor inicial del CRC
    uint8_t crc = 0x00; 

    for (size_t i = 0; i < len; ++i) {
        crc ^= data[i];

        for (int j = 0; j < 8; ++j) {
            if (crc & 0x80) { // Si el bit m?s significativo es 1
                crc = (crc << 1) ^ poly;
            } else {
                crc = (crc << 1);
            }
        }
    }

    return crc;
}



int main(void)
{

   

    pinMode(PD2,INPUT); //SDATA 
    pinMode(PD3,INPUT); //SCL 
    pinMode(PD4,INPUT); //RESET

  //  srand((unsigned int)time(NULL));

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
       
    Delay_Init();
    USART_Printf_Init(115200);
    SystemCoreClockUpdate();

    SysTick->CTLR = 0x5;        // Enable SysTick and use the processor clock
    SysTick->CNT  = 0;          // Clear the current value to 0

    //printf("EMULANDO BU9850\n");
    
    //printf("Empieza a cargar\n");
    leer_buffer_de_flash();
    //printf("Termina de cargar\n");

    int8_t resetea=1;    
    for(int i=0;i<512;i++){
        if(buffer[i]!=0xFF){ resetea=0; }               
    }

    if(resetea==1){
      for(int i=0;i<512;i++){
          buffer[i]=0x00;
          guardar_buffer_en_flash(buffer);
      }    

    }


    int8_t valor0;
    int8_t valor1;
    int8_t valor2;
    int8_t valor3;
    int8_t valor4;
    int8_t valor5;
    int8_t valor6;
    int8_t valor7;
    
    int contador=0;
    int guardado=1;
    int8_t contadorLOW=0;
    int8_t comando=0;
    int8_t registro=0;
    int i;

    while(1){      

        //recibe byte comando  

        contador=0;       
        comando=0;
        registro=0;
        valor0=0;
        valor1=0;
        valor2=0;
        valor3=0;
        valor4=0;
        valor5=0;
        valor6=0;
        valor7=0;

        while(digitalReadPD2){           
          if(guardado==0){              
              contador++;
              if(contador>100000){
                  guardado=1;
                  guardar_buffer_en_flash(buffer); 
              }
          }
        }


        while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ comando |= (1 << 7); }contadorLOW=0;                               
        while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ comando |= (1 << 6); }contadorLOW=0;                               
        while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ comando |= (1 << 5); }contadorLOW=0;                               
        while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ comando |= (1 << 4); }contadorLOW=0;                               
        while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ comando |= (1 << 3); }contadorLOW=0;                               
        while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ comando |= (1 << 2); }contadorLOW=0;                               
        while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ comando |= (1 << 1); }contadorLOW=0;                               
        while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ comando |= (1 << 0); }contadorLOW=0;                               
           
             
        if(comando==0){    //La n64 solicita informacion del dispositivo

            //enviabyte(0x00);
            //enviabyte(0x80);   //4KB
            //enviabyte(0x00);

            pinMode(PD2,OUTPUT);

             for(i=7;i>=0;i--){     
                apagaPD2;
                Delay_750ns();       
                Delay_750ns();       
                Delay_750ns();       
             
                enciendePD2;    
                Delay_750ns();       
             }

             apagaPD2;
             Delay_750ns();       
             
             enciendePD2;    
             Delay_750ns(); 
             Delay_750ns();       
             Delay_750ns();      
             

             for(i=6;i>=0;i--){     
                apagaPD2;
                Delay_750ns();       
                Delay_750ns();       
                Delay_750ns();       
             
                enciendePD2;    
                Delay_750ns();       
             }

             for(i=7;i>=0;i--){     
                apagaPD2;
                Delay_750ns();       
                Delay_750ns();       
                Delay_750ns();       
             
                enciendePD2;    
                Delay_750ns();      
             }

              //Bit de final
              apagaPD2;Delay_750ns();                     
              enciendePD2;Delay_750ns();Delay_750ns();Delay_750ns();  

             pinMode(PD2,INPUT);


        }else if(comando==5){  //comando==5 Se realiza la escritura en la EEPROM

            //recibe byte registro

            while(digitalReadPD2){ /*__asm volatile("nop\n");*/ }
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ registro |= (1 << 7); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ registro |= (1 << 6); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ registro |= (1 << 5); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ registro |= (1 << 4); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ registro |= (1 << 3); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ registro |= (1 << 2); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ registro |= (1 << 1); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ registro |= (1 << 0); }contadorLOW=0;                               
                              
                  
            while(digitalReadPD2){ /*__asm volatile("nop\n");*/ }
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor0 |= (1 << 7); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor0 |= (1 << 6); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor0 |= (1 << 5); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor0 |= (1 << 4); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor0 |= (1 << 3); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor0 |= (1 << 2); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor0 |= (1 << 1); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor0 |= (1 << 0); }contadorLOW=0;                               
                   
            while(digitalReadPD2){ /*__asm volatile("nop\n");*/ }
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor1 |= (1 << 7); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor1 |= (1 << 6); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor1 |= (1 << 5); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor1 |= (1 << 4); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor1 |= (1 << 3); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor1 |= (1 << 2); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor1 |= (1 << 1); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor1 |= (1 << 0); }contadorLOW=0;                               
            
                   
            while(digitalReadPD2){ /*__asm volatile("nop\n");*/ }
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor2 |= (1 << 7); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor2 |= (1 << 6); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor2 |= (1 << 5); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor2 |= (1 << 4); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor2 |= (1 << 3); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor2 |= (1 << 2); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor2 |= (1 << 1); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor2 |= (1 << 0); }contadorLOW=0;                               
            

            while(digitalReadPD2){ /*__asm volatile("nop\n");*/ }
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor3 |= (1 << 7); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor3 |= (1 << 6); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor3 |= (1 << 5); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor3 |= (1 << 4); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor3 |= (1 << 3); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor3|= (1 << 2); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor3 |= (1 << 1); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor3 |= (1 << 0); }contadorLOW=0;                               
            
                  
            while(digitalReadPD2){ /*__asm volatile("nop\n");*/ }
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor4 |= (1 << 7); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor4 |= (1 << 6); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor4 |= (1 << 5); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor4 |= (1 << 4); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor4 |= (1 << 3); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor4 |= (1 << 2); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor4 |= (1 << 1); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor4 |= (1 << 0); }contadorLOW=0;                               
            
                            
            while(digitalReadPD2){ /*__asm volatile("nop\n");*/ }
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor5 |= (1 << 7); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor5 |= (1 << 6); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor5 |= (1 << 5); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor5 |= (1 << 4); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor5 |= (1 << 3); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor5 |= (1 << 2); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor5 |= (1 << 1); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor5 |= (1 << 0); }contadorLOW=0;                               
            
                             
            while(digitalReadPD2){ /*__asm volatile("nop\n");*/ }
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor6 |= (1 << 7); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor6 |= (1 << 6); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor6 |= (1 << 5); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor6 |= (1 << 4); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor6 |= (1 << 3); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor6 |= (1 << 2); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor6 |= (1 << 1); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor6 |= (1 << 0); }contadorLOW=0;                               
            
                              
            while(digitalReadPD2){ /*__asm volatile("nop\n");*/ }
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor7 |= (1 << 7); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor7 |= (1 << 6); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor7 |= (1 << 5); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor7 |= (1 << 4); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor7 |= (1 << 3); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor7 |= (1 << 2); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor7 |= (1 << 1); }contadorLOW=0;                               
            while(!(digitalReadPD2)){contadorLOW++;}while(digitalReadPD2){ contadorLOW--; }if(contadorLOW<0){ valor7 |= (1 << 0); }contadorLOW=0;                               
            

            //Hay que guardarlo en la flash del ch32, para luego poder recuperarlo. 
            
            //recibebitfinal(); 

            /*
            Delay_750ns();Delay_750ns();
            Delay_750ns();Delay_750ns();
            Delay_750ns();Delay_750ns();
            Delay_750ns();Delay_750ns();
            */

            //uint8_t crc=crc8_poly_85(valor,8);
            
            /*         
            ///Se envia CRC
            pinMode(PD2,OUTPUT); 

            for (int j = 7;j>=0;j--) {
                if(((crc >> j) & 1)==0){                
                    apagaPD2;Delay_750ns(); Delay_750ns(); Delay_750ns(); 
                    enciendePD2;        
                }else{
                    apagaPD2;Delay_750ns();
                    enciendePD2;Delay_750ns(); Delay_750ns(); Delay_750ns();   
                }
            }            
            */ 

            pinMode(PD2,OUTPUT);

            apagaPD2;Delay_750ns();Delay_750ns();Delay_750ns();                     
            enciendePD2;Delay_750ns();
            apagaPD2;Delay_750ns();Delay_750ns();Delay_750ns();                     
            enciendePD2;Delay_750ns();
            apagaPD2;Delay_750ns();Delay_750ns();Delay_750ns();                     
            enciendePD2;Delay_750ns();
            apagaPD2;Delay_750ns();Delay_750ns();Delay_750ns();                     
            enciendePD2;Delay_750ns();
            apagaPD2;Delay_750ns();Delay_750ns();Delay_750ns();                     
            enciendePD2;Delay_750ns();
            apagaPD2;Delay_750ns();Delay_750ns();Delay_750ns();                     
            enciendePD2;Delay_750ns();
            apagaPD2;Delay_750ns();Delay_750ns();Delay_750ns();                     
            enciendePD2;Delay_750ns();
            apagaPD2;Delay_750ns();Delay_750ns();Delay_750ns();                     
            enciendePD2;Delay_750ns();
  
            //Bit de final
            apagaPD2;Delay_750ns();                     
            enciendePD2;Delay_750ns();Delay_750ns();Delay_750ns();

            pinMode(PD2,INPUT);  
            

            buffer[(registro*8)]=valor0;
            buffer[(registro*8)+1]=valor1;
            buffer[(registro*8)+2]=valor2;
            buffer[(registro*8)+3]=valor3;
            buffer[(registro*8)+4]=valor4;
            buffer[(registro*8)+5]=valor5;
            buffer[(registro*8)+6]=valor6;
            buffer[(registro*8)+7]=valor7;
            

            guardado=0;
            //guardar_buffer_en_flash_bloque(buffer,registro/64);
            
            //guardar_buffer_en_flash(buffer);  

            //guardado=0;

            //printf("\n");
            //for(int i=0;i<8;i++){
                //printf("%d,",valor[i]);
            //}
            //printf("\n");
            
            
        }else if(comando==4){     //Se realiza la lectura de la EEPROM
            
            registro=recibedato();

            int pos=registro*8;            
            //recibebitfinal();
            //printf("\n%d , %d",comando,registro);
            //Hay que enviar el valor del registro            
            enviadato(pos);
            //recibebitfinal();            
            //contador++;
        }
        
        
        
    }

    //printf("Interrupcion\r\n");
    //Delay_Ms(5000);
    
}


